(function () {
  // standard editor
  var editor8 = new Quill("#editor8", {
    modules: { toolbar: "#toolbar8" },
    theme: "snow",
    placeholder: "Enter your messages...",
  });
})();
