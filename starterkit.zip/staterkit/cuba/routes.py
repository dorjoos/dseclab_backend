from flask import Flask, render_template,redirect,flash,Blueprint
from cuba import db

main = Blueprint('main',__name__)


@main.route('/')
@main.route('/index')
def indexPage():
   context={"breadcrumb":{"parent":"Layout Light","child":"Color version"}}
   return render_template('general/index.html',**context)

